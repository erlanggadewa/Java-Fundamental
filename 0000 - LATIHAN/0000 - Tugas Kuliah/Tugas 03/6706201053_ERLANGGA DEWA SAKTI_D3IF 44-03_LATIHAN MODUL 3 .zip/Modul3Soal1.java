public class Modul3Soal1 {
    public static void main(String[] args) {
        int penumpang1 = 2;
        int penumpang2 = 4;
        int penumpang3 = 3;
        int penumpang4 = 1;
        int penumpang5 = 2;
        int penumpang6 = 4;
        int penumpang7 = 3;
        int totalPenumpang = penumpang1 + penumpang2 + penumpang3 + penumpang4 + penumpang5 + penumpang6 + penumpang7;
        System.out.println("Jumlah orderan pertama sebanyak\t= " + penumpang1);
        System.out.println("Jumlah orderan kedua sebanyak\t= " + penumpang2);
        System.out.println("Jumlah orderan ketiga sebanyak\t= " + penumpang3);
        System.out.println("Jumlah orderan keempat sebanyak\t= " + penumpang4);
        System.out.println("Jumlah orderan kelima sebanyak\t= " + penumpang5);
        System.out.println("Jumlah orderan keenam sebanyak\t= " + penumpang6);
        System.out.println("Jumlah orderan ketujuh sebanyak\t= " + penumpang7);
        System.out.println("-----------------------------------------------------");
        System.out.println("Total banyaknya penumpang dalam sehari sejumlah = " + totalPenumpang);
    }
}
